RWD MASTER — GITHUB PAGES HOSTING VERSION

FILES INCLUDED
- index.html
- manifest.json
- icon.svg

HOW TO HOST FREE WITH GITHUB PAGES

1. Go to github.com
2. Create a free account or log in.
3. Tap + / New repository.
4. Repository name:
   rwd-master-app
5. Set it to Public.
6. Create repository.
7. Tap Add file > Upload files.
8. Upload these 3 files:
   index.html
   manifest.json
   icon.svg
9. Commit changes.
10. Go to Settings > Pages.
11. Under Branch, choose:
   main
   /root
12. Tap Save.
13. Wait 1-3 minutes.
14. Your app link will look like:
   https://YOUR-GITHUB-NAME.github.io/rwd-master-app/

INSTALL ON IPHONE
1. Open that GitHub Pages link in Safari.
2. Tap Share.
3. Tap Add to Home Screen.
4. Name it RWD Master.
5. Tap Add.

IMPORTANT
Do not use Netlify. This version is made for GitHub Pages.
VIN/NHTSA lookup needs internet. The rest of the app runs in the browser/app.
